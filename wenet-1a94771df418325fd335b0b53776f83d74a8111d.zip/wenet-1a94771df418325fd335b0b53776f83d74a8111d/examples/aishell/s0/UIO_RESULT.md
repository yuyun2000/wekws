# Benchmark on Conformer

| IO           | CER   |
|--------------|-------|
| Old          | 4.61  |
| UIO(Raw)     | 4.63  |
| UIO(Shards)  | 4.67  |


