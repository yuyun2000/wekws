.. wenet documentation master file, created by
   sphinx-quickstart on Thu Dec  3 11:43:53 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to wenet's documentation!
=================================


wenet is an tansformer-based end-to-end ASR toolkit.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   ./python_package.md
   ./train.rst
   ./production.rst
   ./reference.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
